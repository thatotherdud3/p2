/* ==========================================================================
   G L H // CO-OP - DATA INJECTION BRIDGE (app.js)
   ========================================================================== */

/* --- CART STATE MANAGEMENT --- */
let cart = JSON.parse(localStorage.getItem('glh_cart')) || [];

function saveCart() {
    localStorage.setItem('glh_cart', JSON.stringify(cart));
    updateCartCount();
}

function updateCartCount() {
    const counts = document.querySelectorAll('.nav-item');
    counts.forEach(el => {
        if(el.innerText.includes('CART')) {
            el.innerText = `CART [${cart.reduce((sum, item) => sum + item.quantity, 0)}]`;
        }
    });
}

function addToCart(id, name, price, stock) {
    if (stock <= 0) {
        alert("SYSTEM HALT: Inventory depleted.");
        return;
    }
    
    let existing = cart.find(i => i.product_id === id);
    if (existing) {
        if (existing.quantity >= stock) {
            alert(`SYSTEM HALT: Maximum available stock (${stock}) reached.`);
            return;
        }
        existing.quantity += 1;
    } else {
        cart.push({ product_id: id, product_name: name, price: price, quantity: 1, max_stock: stock });
    }
    
    saveCart();
    console.log(`ASSET SECURED: ${name} added to local cart.`);
}

/* ==========================================================================
   INVENTORY RETRIEVAL & DISTRIBUTION
   ========================================================================== */

function fetchInventoryData(url) {
  const cacheBustUrl = `${url}?t=${new Date().getTime()}`;

  fetch(cacheBustUrl, { cache: "no-store" })
    .then((response) => {
      if (!response.ok)
        throw new Error("Network latency or server rejection detected.");
      return response.json();
    })
    .then((data) => {
      console.log("SYSTEM LOG: Data payload secured.", data);
      distributeData(data);
    })
    .catch((error) => console.error("SYSTEM ERROR:", error));
}

function distributeData(inventory) {
  const shopGrid = document.getElementById("shop-inventory-grid");
  const ledgerTable = document.getElementById("producer-ledger-body");

  if (shopGrid) populateShop(inventory, shopGrid);
  if (ledgerTable) {
    const activeProducerId = parseInt(localStorage.getItem("session_user_id"), 10);
    const ownInventory = inventory.filter(item => item.producer_id === activeProducerId);
    populateLedger(ownInventory, ledgerTable);
  }
}

/* --- CLIENT NODE: SHOP PRODUCE INJECTION --- */
/* --- CLIENT NODE: SHOP PRODUCE INJECTION --- */
function populateShop(inventory, container) {
  container.innerHTML = "";

  inventory.forEach((item) => {
    const card = document.createElement("div");
    card.className = "product-card";

    // Dynamic Asset Routing
    let imagePath = "placeholder.png";
    if (item.product_image && item.product_image !== "placeholder.png") {
      imagePath = `assets/${item.product_image}`;
    }

    // Dynamic Stock Status & Button Logic
    let status = "IN STOCK";
    let badgeClass = "active";
    let actionText = "ADD TO CART";
    let actionIcon = "+";

    if (item.stock_level === 0) {
      status = "OUT OF STOCK";
      badgeClass = "out-of-stock";
      actionText = "NOT AVAILABLE";
      actionIcon = "/";
    } else if (item.stock_level <= 20) {
      status = "LOW STOCK";
      badgeClass = "low-stock";
    }

    // Brutalist String Formatting
    let formattedAllergens = `[${item.allergen_info.toUpperCase()}]`;
    let formattedPrice = `£${parseFloat(item.price).toFixed(2)}`;

    card.innerHTML = `
        <div class="product-image-slot" style="width: 100%; aspect-ratio: 4 / 3; overflow: hidden; border-bottom: 1px solid #111111;">
          <img
            class="product-image"
            src="${imagePath}"
            alt="${item.product_name}"
            style="width: 100%; height: 100%; object-fit: cover; display: block; background-color: #e0e0e0;"
          />
        </div>
        <div class="product-details">
          <div class="product-header">
            <span class="product-vendor">PRODUCER: ${item.producer_name.toUpperCase()}</span>
            <div class="product-meta-right">
              <span class="box-index">${item.batch_number}</span>
              <span class="status-badge ${badgeClass}">${status}</span>
            </div>
          </div>
          <h2 class="box-title">${item.product_name}</h2>
          <span class="product-allergen">${formattedAllergens}</span>
          <span class="product-price">${formattedPrice}</span>
        </div>
        <button class="product-action" onclick="addToCart(${item.product_id}, '${item.product_name.replace(/'/g, "\\'")}', ${item.price}, ${item.stock_level})">
          <span>${actionText}</span>
          <span class="action-icon">${actionIcon}</span>
        </button>
    `;

    container.appendChild(card);
  });
}

/* --- PRODUCER NODE: LEDGER INJECTION --- */
function populateLedger(inventory, container) {
  container.innerHTML = "";

  inventory.forEach((item) => {
    let status = "ACTIVE";
    let badgeClass = "active";

    if (item.stock_level === 0) {
      status = "OUT OF STOCK";
      badgeClass = "out-of-stock";
    } else if (item.stock_level <= 20) {
      status = "LOW STOCK";
      badgeClass = "low-stock";
    }

    const row = document.createElement("tr");
    row.innerHTML = `
            <td class="sku-cell">${item.batch_number}</td>
            <td class="name-cell">${item.product_name}</td>
            <td class="data-cell">${item.stock_level}</td>
            <td class="data-cell">£${parseFloat(item.price).toFixed(2)}</td>
            <td class="data-cell">
                <span class="status-badge ${badgeClass}">${status}</span>
            </td>
            <td class="action-cell">
                <button class="ledger-remove-btn" onclick="deleteProduct(${item.product_id})">[ REMOVE ]</button>
            </td>
        `;
    container.appendChild(row);
  });
}

/* ==========================================================================
   WRITE OPERATIONS: PRODUCER INTAKE MANIFEST
   ========================================================================== */

const ledgerForm = document.getElementById("ledger-form");

if (ledgerForm) {
  ledgerForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const allergenCheckboxes = document.querySelectorAll(
      ".allergen-check:checked",
    );
    if (allergenCheckboxes.length === 0) {
      alert(
        "SYSTEM HALT: Regulatory compliance failure. Select at least one allergen.",
      );
      return;
    }

    const formData = new FormData();
    const imageFile = document.getElementById("input-image").files[0];

    const activeProducerId = localStorage.getItem("session_user_id") || 1;
    formData.append("producer_id", activeProducerId);

    formData.append(
      "batch_number",
      ledgerForm.querySelector('input[placeholder="e.g. BATCH-2026-X1"]').value,
    );
    formData.append(
      "product_name",
      ledgerForm.querySelector('input[placeholder="Product Descriptor"]').value,
    );
    formData.append(
      "stock_level",
      document.getElementById("input-stock").value,
    );
    formData.append("price", document.getElementById("input-price").value);

    let allergens = Array.from(allergenCheckboxes)
      .map((cb) => cb.parentElement.textContent.trim())
      .join(", ");
    formData.append("allergen_info", allergens);

    if (imageFile) {
      formData.append("product_image", imageFile);
    }

    fetch("http://127.0.0.1:8000/products", {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (!response.ok) throw new Error("Server rejected the asset upload.");
        return response.json();
      })
      .then((data) => {
        alert("Stock and Visual Asset successfully committed.");
        ledgerForm.reset();
        fetchInventoryData("http://127.0.0.1:8000/products");
      })
      .catch((error) => {
        console.error("POST ERROR:", error);
        alert("SYSTEM HALT: Failed to commit stock. " + error.message);
      });
  });
}

/* --- DELETE OPERATION --- */
function deleteProduct(productId) {
  if (
    !confirm(
      `SYSTEM QUERY: Authorize permanent deletion of Product ID ${productId}?`,
    )
  )
    return;

  fetch(`http://127.0.0.1:8000/products/${productId}`, {
    method: "DELETE",
    mode: "cors",
    headers: { "Access-Control-Allow-Origin": "*" },
  })
    .then((response) => {
      if (response.ok) {
        console.log(`DELETION SUCCESS: ID ${productId} purged.`);
        fetchInventoryData("http://127.0.0.1:8000/products");
      } else {
        throw new Error("Server rejected the purge request.");
      }
    })
    .catch((error) => {
      console.error("DELETION ERROR:", error);
      alert("CRITICAL ERROR: Purge failed.");
    });
}

/* ==========================================================================
   IDENTITY & AUTHENTICATION PROTOCOLS
   ========================================================================== */

let authFormObj = document.querySelector(".auth-form");
let isLoginMode = document.getElementById("user-id");
let isRegistrationMode = document.getElementById("passkey-confirm");

if (authFormObj) {
  authFormObj.addEventListener("submit", function (event) {
    event.preventDefault(); 

    // --- MODULE 1: REGISTRATION LOGIC ---
    if (isRegistrationMode) {
      const fullName = document.getElementById("customer-alias").value;
      const email = document.getElementById("customer-email").value;
      const password = document.getElementById("passkey").value;
      const confirmPassword = document.getElementById("passkey-confirm").value;

      if (password !== confirmPassword) {
        alert("SYSTEM HALT: Passkeys do not match. Verification failed.");
        return;
      }

      console.log(`SYSTEM LOG: Initiating registration for [${email}]...`);

      fetch("http://127.0.0.1:8000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ full_name: fullName, email: email, password: password, role: "customer" }),
      })
      .then(res => {
        if (!res.ok && res.status !== 409) throw new Error("Server failure.");
        return res.json();
      })
      .then(data => {
        if (data.status === "success") {
          alert("Account successfully established. Proceeding to authentication portal.");
          window.location.href = "customer-login.html";
        } else {
          alert(`SYSTEM HALT: Registration Denied. ${data.message}`);
        }
      }).catch(err => console.error("REG ERROR:", err));
    }

    // --- MODULE 3: LOGIN LOGIC ---
    else if (isLoginMode) {
      const email = document.getElementById("user-id").value;
      const password = document.getElementById("passkey").value;

      const modeText = document.querySelector(".auth-mode").innerText;
      const requestedNode = modeText.includes("PRODUCER") ? "producer" : "customer";

      console.log(`SYSTEM LOG: Initiating authentication for [${email}] on [${requestedNode.toUpperCase()}] node...`);

      fetch("http://127.0.0.1:8000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          email: email, 
          password: password,
          requested_node: requestedNode 
        }),
      })
      .then(res => {
        if (!res.ok && res.status !== 401 && res.status !== 403) throw new Error("Server failure.");
        return res.json();
      })
      .then(data => {
        if (data.status === "success") {
          console.log(`AUTH SUCCESS: Role: ${data.role.toUpperCase()}`);
          
          localStorage.setItem("session_user_id", data.user_id);
          localStorage.setItem("session_role", data.role);
          localStorage.setItem("session_full_name", data.full_name);
          
          window.location.href = data.redirect_url;
        } else {
          alert(`SYSTEM HALT: Access Denied. ${data.message}`);
          document.getElementById("passkey").value = "";
        }
      }).catch(err => console.error("AUTH ERROR:", err));
    }
  });
}

/* ==========================================================================
   SESSION MANAGEMENT: IDENTITY, GUARDS, LOGOUT, ACCOUNT DELETION
   ========================================================================== */

function initSessionUI() {
    const userId   = localStorage.getItem("session_user_id");
    const role     = localStorage.getItem("session_role");
    const name     = localStorage.getItem("session_full_name");
    const page     = window.location.pathname.split('/').pop() || 'index.html';

    // --- PAGE GUARDS ---
    if (page === 'customer-portal.html' && !userId) {
        window.location.href = 'customer-login.html';
        return;
    }
    if (page === 'producer-portal.html' && role !== 'producer') {
        window.location.href = 'producer-login.html';
        return;
    }

    if (page === 'customer-login.html' && userId && role === 'customer') {
        window.location.href = 'customer-portal.html';
        return;
    }
    if (page === 'producer-login.html' && userId && role === 'producer') {
        window.location.href = 'producer-portal.html';
        return;
    }

    // --- NAV INJECTION ---
    if (userId) {
        const navRight = document.querySelector('.nav-right');
        if (navRight && !document.getElementById('logout-btn')) { 
            const logoutBtn = document.createElement('a');
            logoutBtn.href = "#";
            logoutBtn.className = "nav-item";
            logoutBtn.id = "logout-btn";
            logoutBtn.innerText = "LOGOUT";
            
            navRight.appendChild(logoutBtn);

            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                logout();
            });
        }
    }

    // --- PRODUCER TERMINAL IDENTITY ---
    const farmerNameSlot = document.getElementById("active-farmer-name");
    const farmNameSlot   = document.getElementById("active-farm-name");
    if (farmerNameSlot && name) {
        farmerNameSlot.innerText = name.toUpperCase();
        if (farmNameSlot) {
            farmNameSlot.innerText = `TERMINAL // ${name.toUpperCase()}`;
        }
    }

    // --- CUSTOMER PORTAL IDENTITY ---
    const welcomeTitle = document.getElementById("welcome-title");
    if (welcomeTitle && name) {
        welcomeTitle.innerText = `Welcome Back, ${name.split(' ')[0]}.`;
    }

    // --- MANAGE ACCOUNT BUTTON ---
    const manageBtn = document.getElementById("manage-account-btn");
    if (manageBtn) {
        manageBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showAccountOptions();
        });
    }
}

function logout() {
    localStorage.removeItem('session_user_id');
    localStorage.removeItem('session_role');
    localStorage.removeItem('session_full_name');
    window.location.href = 'index.html';
}

function deleteAccount() {
    const userId = localStorage.getItem('session_user_id');
    if (!userId) return;

    if (!confirm('SYSTEM QUERY: Authorize permanent account deletion? This action cannot be undone.')) return;

    fetch(`http://127.0.0.1:8000/users/${userId}`, { method: 'DELETE' })
        .then(response => {
            if (response.ok) {
                alert('Account successfully purged from system.');
                logout();
            } else {
                throw new Error('Server rejected deletion.');
            }
        })
        .catch(err => {
            console.error('ACCOUNT DELETION ERROR:', err);
            alert('CRITICAL ERROR: Account deletion failed.');
        });
}

function showAccountOptions() {
    const existing = document.getElementById('account-modal');
    if (existing) { existing.remove(); return; }

    const modal = document.createElement('div');
    modal.id = 'account-modal';
    modal.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: #fbfbf9; border: 1px solid #111; padding: 48px;
        z-index: 9999; min-width: 320px; font-family: 'Courier New', monospace;
    `;
    const name = localStorage.getItem('session_full_name') || 'User';
    modal.innerHTML = `
        <span style="font-size:11px; letter-spacing:0.1em; color:#666;">ACCOUNT MANAGEMENT</span>
        <h2 style="margin: 16px 0 32px; font-size: 24px;">${name.toUpperCase()}</h2>
        <button onclick="deleteAccount()" style="display:block; width:100%; padding:16px; background:#111; color:#fff; font-family:inherit; font-size:12px; letter-spacing:0.1em; cursor:pointer; border:none; margin-bottom:12px;">
            [ DELETE ACCOUNT ]
        </button>
        <button onclick="document.getElementById('account-modal').remove()" style="display:block; width:100%; padding:16px; background:transparent; color:#111; font-family:inherit; font-size:12px; letter-spacing:0.1em; cursor:pointer; border:1px solid #111;">
            [ CANCEL ]
        </button>
    `;
    document.body.appendChild(modal);
}

/* ==========================================================================
   MODULE 4: ACTIVE CART RENDERING & TRANSACTIONAL LOGIC
   ========================================================================== */

function renderCartPage() {
    const cartContainer = document.querySelector('.cart-items');
    if (!cartContainer) return; 

    cartContainer.innerHTML = '';
    let subtotal = 0;

    if (cart.length === 0) {
        cartContainer.innerHTML = '<p class="system-label" style="padding: 40px 0;">Cart matrix is currently empty.</p>';
    } else {
        cart.forEach((item, index) => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;

            const article = document.createElement('article');
            article.className = 'cart-item';
            
            const formattedAllergen = item.allergen_info ? `[ALLERGEN: ${item.allergen_info.toUpperCase()}]` : '[NO ALLERGEN DATA]';
            const producerName = item.producer_name ? item.producer_name.toUpperCase() : 'GLH CO-OP';

            article.innerHTML = `
                <div class="item-media">
                  <img src="assets/${item.product_image || 'placeholder.png'}" alt="${item.product_name}" style="width:100%; height:100%; object-fit:cover; background:#e0e0e0;"/>
                </div>
                <div class="item-details">
                  <h2 class="item-name">${item.product_name.toUpperCase()}</h2>
                  <span class="item-allergen">${formattedAllergen}</span>
                  <p class="item-farm">${producerName}</p>
                </div>
                <div class="item-metrics">
                  <div class="metric-cell price">£${item.price.toFixed(2)}</div>
                  <div class="metric-cell qty">
                    <input type="number" value="${item.quantity}" min="1" max="${item.max_stock}" class="qty-input" onchange="updateItemQty(${index}, this.value)" style="width:100%; text-align:center; border:none; background:transparent; font-family:inherit;" />
                  </div>
                  <button class="metric-cell remove-btn" onclick="removeItem(${index})" style="border:none; background:transparent; font-family:inherit; cursor:pointer;">[ REMOVE ]</button>
                </div>
            `;
            cartContainer.appendChild(article);
        });
    }

    updateOrderSummary(subtotal);
}

function updateItemQty(index, newQty) {
    const parsedQty = parseInt(newQty, 10);
    
    if (parsedQty > cart[index].max_stock) {
        alert(`SYSTEM HALT: Request exceeds available inventory. Maximum allowance is ${cart[index].max_stock} units.`);
        cart[index].quantity = cart[index].max_stock;
    } else if (parsedQty < 1) {
        cart[index].quantity = 1;
    } else {
        cart[index].quantity = parsedQty;
    }
    saveCart();
    renderCartPage();
}

function removeItem(index) {
    cart.splice(index, 1);
    saveCart();
    renderCartPage();
}

function updateOrderSummary(subtotal) {
    const summaryTable = document.querySelector('.summary-totals');
    if (!summaryTable) return;

    const deliveryMethod = document.querySelector('input[name="delivery-method"]:checked').value;
    const deliveryFee = deliveryMethod === 'direct' ? 5.00 : 0.00;
    
    const vat = subtotal * 0.00; 
    const total = subtotal + vat + deliveryFee;

    const numericCells = summaryTable.querySelectorAll('.numeric');
    if (numericCells.length === 4) {
        numericCells[0].innerText = `£ ${subtotal.toFixed(2)}`;
        numericCells[1].innerText = `£ ${vat.toFixed(2)}`;
        numericCells[2].innerText = `£ ${deliveryFee.toFixed(2)}`;
        numericCells[3].innerText = `£ ${total.toFixed(2)}`;
    }
}

function initiateCheckout() {
    const userId = localStorage.getItem("session_user_id");
    
    if (!userId || localStorage.getItem("session_role") !== "customer") {
        alert("SYSTEM LOG: Authentication required to execute transaction. Routing to Customer Node.");
        window.location.href = "customer-login.html";
        return;
    }

    if (cart.length === 0) {
        alert("SYSTEM HALT: Cannot process an empty ledger.");
        return;
    }
    
    const totalString = document.querySelectorAll('.summary-totals .numeric')[3].innerText.replace('£', '').trim();
    const finalTotal = parseFloat(totalString);
    
    fetch("http://127.0.0.1:8000/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            customer_id: userId,
            cart: cart,
            total_price: finalTotal
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "success") {
            alert(`TRANSACTION COMPLETE: Order Ref #${data.order_id} committed to ledger.`);
            cart = []; 
            saveCart();
            window.location.href = "customer-portal.html"; 
        } else {
            alert(`SYSTEM ERROR: ${data.message}`);
        }
    }).catch(err => console.error("CHECKOUT ERROR:", err));
}

/* ==========================================================================
   SINGLE DOMContentLoaded ENTRY POINT
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
    initSessionUI();
    updateCartCount();

    const page = window.location.pathname.split('/').pop() || 'index.html';

    if (page === 'products.html' || page === 'producer-portal.html') {
        fetchInventoryData("http://127.0.0.1:8000/products");
    }

    if (page === 'cart.html') {
        renderCartPage();

        const deliveryToggles = document.querySelectorAll('input[name="delivery-method"]');
        deliveryToggles.forEach(toggle => {
            toggle.addEventListener('change', renderCartPage);
        });

        const submitBtn = document.querySelector('.cart-submit');
        if (submitBtn) {
            submitBtn.addEventListener('click', (e) => {
                e.preventDefault();
                initiateCheckout();
            });
        }
    }
});