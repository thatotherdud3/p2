import json
import sqlite3
import hashlib
import os
from http.server import SimpleHTTPRequestHandler, HTTPServer
from email.parser import BytesParser

# --- CONFIGURATION PROTOCOL ---
PORT = 8000
FRONTEND_DIR = "frontend"
ASSET_DIR = os.path.join(FRONTEND_DIR, "assets")

# Ensure asset directory persistence
if not os.path.exists(ASSET_DIR):
    os.makedirs(ASSET_DIR)

# --- DATABASE LAYER ---

def get_db_connection():
    """Establishes connection to the SQLite relational database."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(current_dir, "..", "glh_coop.db")
    
    # Fallback for local execution environments
    if not os.path.exists(db_path):
        db_path = "glh_coop.db" 

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def retrieve_inventory():
    """Extracts product records and dynamically joins the producer's farm name."""
    connection = get_db_connection()
    cursor = connection.cursor()
    
    cursor.execute("""
        SELECT 
            p.*, 
            u.full_name as producer_name 
        FROM products p
        JOIN users u ON p.producer_id = u.user_id
    """)
    
    inventory = cursor.fetchall()
    connection.close()
    return [dict(row) for row in inventory]

def insert_inventory(data):
    """Commits new product metadata and asset references to SQLite."""
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO products (producer_id, product_name, price, stock_level, allergen_info, batch_number, product_image)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        data.get("producer_id"),
        data.get("product_name"),
        data.get("price"),
        data.get("stock_level"),
        data.get("allergen_info"),
        data.get("batch_number"),
        data.get("product_image")
    ))
    connection.commit()
    connection.close()
    print(f"CORE LOG: Asset {data.get('product_name')} successfully committed to ledger.")

# --- API HANDLER LOGIC ---

class NativeAPIHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=FRONTEND_DIR, **kwargs)

    def do_OPTIONS(self):
        """Authorizes cross-origin pre-flight requests."""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        """Handles data retrieval and static file serving."""
        if self.path == '/products' or self.path.startswith('/products?'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            data = retrieve_inventory()
            self.wfile.write(json.dumps(data).encode('utf-8'))
        else:
            super().do_GET()

    def do_POST(self):
        """Handles inbound data streams (Registration, Authentication, Inventory & Checkout)."""
        
        # --- MODULE 1: ACCOUNT CREATION ENDPOINT ---
        if self.path == '/register':
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                post_data = self.rfile.read(content_length)
                payload = json.loads(post_data.decode('utf-8'))
                
                full_name = payload.get("full_name")
                email = payload.get("email")
                raw_password = payload.get("password")
                role = payload.get("role", "customer") 
                
                hashed_pw = hashlib.sha256(raw_password.encode('utf-8')).hexdigest()
                
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("""
                    INSERT INTO users (full_name, email, password_hash, role)
                    VALUES (?, ?, ?, ?)
                """, (full_name, email, hashed_pw, role))
                
                connection.commit()
                connection.close()
                
                print(f"SECURITY LOG: New identity [{email}] committed to ledger.")
                
                self.send_response(201)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success", "message": "Identity verified and stored."}).encode('utf-8'))
                
            except sqlite3.IntegrityError:
                print(f"SECURITY ALERT: Registration collision. Identity [{email}] already exists.")
                self.send_response(409)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "error", "message": "Email already registered."}).encode('utf-8'))
                
            except Exception as e:
                print(f"SYSTEM ERROR: Ingestion failure on /register. {e}")
                self.send_response(500)
                self.end_headers()

        # --- MODULE 3: AUTHENTICATION & ROLE-BASED ROUTING ENDPOINT ---
        elif self.path == '/login':
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                post_data = self.rfile.read(content_length)
                payload = json.loads(post_data.decode('utf-8'))
                
                email = payload.get("email")
                raw_password = payload.get("password")
                requested_node = payload.get("requested_node", "customer")
                
                hashed_pw = hashlib.sha256(raw_password.encode('utf-8')).hexdigest()
                
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("SELECT user_id, full_name, role FROM users WHERE email = ? AND password_hash = ?", (email, hashed_pw))
                user = cursor.fetchone()
                connection.close()
                
                if user:
                    role = user["role"]
                    
                    if requested_node == "producer" and role == "customer":
                        print(f"SECURITY ALERT: Hard bounce. Customer identity [{email}] attempted access via Producer Terminal.")
                        self.send_response(403)
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Content-type', 'application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({"status": "error", "message": "Clearance denied. Producer privileges required."}).encode('utf-8'))
                        return

                    target_node = "producer-portal.html" if role == "producer" else "customer-portal.html"
                    
                    print(f"SECURITY LOG: Authentication successful for [{email}]. Node assignment: {role.upper()}.")
                    self.send_response(200)
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({
                        "status": "success", 
                        "role": role,
                        "user_id": user["user_id"], 
                        "full_name": user["full_name"],
                        "redirect_url": target_node
                    }).encode('utf-8'))
                else:
                    print(f"SECURITY ALERT: Unauthorized access attempt for [{email}].")
                    self.send_response(401)
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"status": "error", "message": "Invalid credentials."}).encode('utf-8'))
            
            except Exception as e:
                print(f"SYSTEM ERROR: Authentication failure. {e}")
                self.send_response(500)
                self.end_headers()

        # --- INVENTORY REGISTRATION ENDPOINT ---
        elif self.path == '/products':
            try:
                content_type = self.headers.get('Content-Type')
                content_length = int(self.headers.get('Content-Length'))
                
                raw_body = self.rfile.read(content_length)
                
                headers_string = f"Content-Type: {content_type}\r\n\r\n"
                msg = BytesParser().parsebytes(headers_string.encode() + raw_body)
                
                data = {}
                image_filename = "placeholder.png"

                for part in msg.get_payload():
                    field_name = part.get_param('name', header='content-disposition')
                    
                    if field_name == "product_image":
                        filename = part.get_filename()
                        if filename:
                            image_filename = os.path.basename(filename)
                            save_path = os.path.join(ASSET_DIR, image_filename)
                            with open(save_path, 'wb') as f:
                                f.write(part.get_payload(decode=True))
                    else:
                        data[field_name] = part.get_payload(decode=True).decode('utf-8')
                
                producer_id_raw = data.get("producer_id", 1)

                final_payload = {
                    "producer_id": int(producer_id_raw),
                    "batch_number": data.get("batch_number"),
                    "product_name": data.get("product_name"),
                    "stock_level": int(data.get("stock_level", 0)),
                    "price": float(data.get("price", 0.0)),
                    "allergen_info": data.get("allergen_info"),
                    "product_image": image_filename
                }

                insert_inventory(final_payload)
                
                self.send_response(201)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

            except Exception as e:
                print(f"SYSTEM ERROR: Post-ingestion failure. {e}")
                self.send_response(500)
                self.end_headers()

        # --- MODULE 4: ATOMIC CHECKOUT ENDPOINT ---
        elif self.path == '/checkout':
            connection = get_db_connection()
            cursor = connection.cursor()
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(content_length).decode('utf-8'))
                
                customer_id = payload.get("customer_id")
                cart_items = payload.get("cart", [])
                total_price = payload.get("total_price", 0.0)

                # Initialize Atomic Transaction
                connection.execute("BEGIN TRANSACTION")

                # STEP 1: Verify Stock (SELECT)
                for item in cart_items:
                    cursor.execute("SELECT stock_level FROM products WHERE product_id = ?", (item['product_id'],))
                    row = cursor.fetchone()
                    if not row or row["stock_level"] < item['quantity']:
                        connection.rollback()
                        self.send_response(400)
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Content-type', 'application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({"status": "error", "message": f"Insufficient stock for {item['product_name']}"}).encode('utf-8'))
                        return

                # STEP 2: Generate Master Receipt (INSERT)
                cursor.execute("INSERT INTO orders (customer_id, total_price) VALUES (?, ?)", (customer_id, total_price))
                order_id = cursor.lastrowid

                # STEP 3: Loop and Commit Items (INSERT & UPDATE)
                for item in cart_items:
                    cursor.execute("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)",
                                   (order_id, item['product_id'], item['quantity']))
                    
                    cursor.execute("UPDATE products SET stock_level = stock_level - ? WHERE product_id = ?",
                                   (item['quantity'], item['product_id']))

                # Execute final commit
                connection.commit()
                print(f"TRANSACTION LOG: Order {order_id} successfully processed for Customer {customer_id}.")
                
                self.send_response(201)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success", "order_id": order_id}).encode('utf-8'))

            except Exception as e:
                connection.rollback()
                print(f"TRANSACTION HALTED: Critical failure during checkout. {e}")
                self.send_response(500)
                self.end_headers()
            finally:
                connection.close()

        else:
            print(f"SYSTEM ROUTING ERROR: Unhandled POST request directed to {self.path}")
            self.send_response(404)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

    def do_DELETE(self):
        """Executes the Purge Protocol for specific record IDs."""
        if self.path.startswith('/products/'):
            try:
                product_id = int(self.path.split('/')[-1])
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
                connection.commit()
                connection.close()
                
                print(f"DELETION LOG: ID {product_id} purged from SQLite.")
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
            except Exception as e:
                print(f"DELETION ERROR: {e}")
                self.send_response(500)
                self.end_headers()

        elif self.path.startswith('/users/'):
            try:
                user_id = int(self.path.split('/')[-1])
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("DELETE FROM products WHERE producer_id = ?", (user_id,))
                cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
                connection.commit()
                connection.close()

                print(f"ACCOUNT DELETION LOG: User ID {user_id} and associated data purged.")
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))
            except Exception as e:
                print(f"ACCOUNT DELETION ERROR: {e}")
                self.send_response(500)
                self.end_headers()

# --- INITIALIZATION ---

if __name__ == "__main__":
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, NativeAPIHandler)
    print(f"SYSTEM LOG: GLH // CO-OP Native API initialized at http://127.0.0.1:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nSYSTEM LOG: Shutdown signal received. Closing server.")
        httpd.server_close()