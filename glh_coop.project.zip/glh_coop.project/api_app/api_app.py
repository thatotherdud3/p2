import json
import sqlite3
import os
from http.server import SimpleHTTPRequestHandler, HTTPServer
from email.parser import BytesParser

# --- CONFIGURATION PROTOCOL ---
PORT = 8000
FRONTEND_DIR = "frontend"
ASSET_DIR = os.path.join(FRONTEND_DIR, "assets")

# Ensure asset directory persistence
if not os.path.exists(ASSET_DIR):
    os.makedirs(ASSET_DIR)

# --- DATABASE LAYER ---

def get_db_connection():
    """Establishes connection to the SQLite relational database."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(current_dir, "..", "glh_coop.db")
    
    # Fallback for local execution environments
    if not os.path.exists(db_path):
        db_path = "glh_coop.db" 

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def retrieve_inventory():
    """Extracts all product records from the ledger."""
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM products")
    inventory = cursor.fetchall()
    connection.close()
    return [dict(row) for row in inventory]

def insert_inventory(data):
    """Commits new product metadata and asset references to SQLite."""
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO products (producer_id, product_name, price, stock_level, allergen_info, batch_number, product_image)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        1, # Hardcoded Producer ID for prototype phase
        data.get("product_name"),
        data.get("price"),
        data.get("stock_level"),
        data.get("allergen_info"),
        data.get("batch_number"),
        data.get("product_image")
    ))
    connection.commit()
    connection.close()
    print(f"CORE LOG: Asset {data.get('product_name')} successfully committed to ledger.")

# --- API HANDLER LOGIC ---

class NativeAPIHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=FRONTEND_DIR, **kwargs)

    def do_OPTIONS(self):
        """Authorizes cross-origin pre-flight requests."""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        """Handles data retrieval and static file serving."""
        if self.path.startswith('/products'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            data = retrieve_inventory()
            self.wfile.write(json.dumps(data).encode('utf-8'))
        else:
            super().do_GET()

    def do_POST(self):
        """Handles multipart/form-data ingestion (Metadata + Binary Assets)."""
        if self.path == '/products':
            try:
                content_type = self.headers.get('Content-Type')
                content_length = int(self.headers.get('Content-Length'))
                
                # Capture the raw binary stream
                raw_body = self.rfile.read(content_length)
                
                # Reconstruct the message for the email.parser
                headers_string = f"Content-Type: {content_type}\r\n\r\n"
                msg = BytesParser().parsebytes(headers_string.encode() + raw_body)
                
                data = {}
                image_filename = "placeholder.png"

                # Iterate through parts of the multipart form
                for part in msg.get_payload():
                    field_name = part.get_param('name', header='content-disposition')
                    
                    if field_name == "product_image":
                        filename = part.get_filename()
                        if filename:
                            image_filename = os.path.basename(filename)
                            save_path = os.path.join(ASSET_DIR, image_filename)
                            with open(save_path, 'wb') as f:
                                f.write(part.get_payload(decode=True))
                    else:
                        data[field_name] = part.get_payload(decode=True).decode('utf-8')

                # Normalize data types for SQLite compatibility
                final_payload = {
                    "batch_number": data.get("batch_number"),
                    "product_name": data.get("product_name"),
                    "stock_level": int(data.get("stock_level", 0)),
                    "price": float(data.get("price", 0.0)),
                    "allergen_info": data.get("allergen_info"),
                    "product_image": image_filename
                }

                insert_inventory(final_payload)
                
                self.send_response(201)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode('utf-8'))

            except Exception as e:
                print(f"SYSTEM ERROR: Post-ingestion failure. {e}")
                self.send_response(500)
                self.end_headers()

    def do_DELETE(self):
        """Executes the Purge Protocol for specific record IDs."""
        if self.path.startswith('/products/'):
            try:
                product_id = int(self.path.split('/')[-1])
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
                connection.commit()
                connection.close()
                
                print(f"DELETION LOG: ID {product_id} purged from SQLite.")
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
            except Exception as e:
                print(f"DELETION ERROR: {e}")
                self.send_response(500)
                self.end_headers()

# --- INITIALIZATION ---

if __name__ == "__main__":
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, NativeAPIHandler)
    print(f"SYSTEM LOG: GLH // CO-OP Native API initialized at http://127.0.0.1:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nSYSTEM LOG: Shutdown signal received. Closing server.")
        httpd.server_close()