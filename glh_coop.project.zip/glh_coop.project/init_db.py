import sqlite3

def repair_database():
    # Connect to the database file
    connection = sqlite3.connect('glh_coop.db')
    cursor = connection.cursor()

    # Drop the old table to ensure the new schema is applied
    cursor.execute("DROP TABLE IF EXISTS products")

    # Inside your setup_database() function:

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        product_id INTEGER PRIMARY KEY AUTOINCREMENT,
        producer_id INTEGER NOT NULL,
        product_name VARCHAR(255) NOT NULL,
        price DOUBLE(10,2) NOT NULL,
        stock_level INTEGER NOT NULL,
        allergen_info VARCHAR(500) NOT NULL,
        batch_number VARCHAR(100) NOT NULL,
        product_image VARCHAR(255) DEFAULT 'placeholder.png', -- ADD THIS LINE
        FOREIGN KEY (producer_id) REFERENCES users(user_id)
    )
    """)
   

    # Seed data (No manual IDs, let AUTOINCREMENT handle it)
    baseline_stock = [
        (1, "Heirloom Carrots", 4.50, 450, "None", "BATCH-2026-A1"),
        (1, "Swiss Chard", 3.00, 120, "None", "BATCH-2026-A2"),
        (1, "Pasture Eggs", 7.50, 0, "Eggs", "BATCH-2026-B1"),
        (1, "Raw Honey", 18.00, 42, "None", "BATCH-2026-C1")
    ]
    
    cursor.executemany("""
    INSERT INTO products (producer_id, product_name, price, stock_level, allergen_info, batch_number)
    VALUES (?, ?, ?, ?, ?, ?)
    """, baseline_stock)

    connection.commit()
    connection.close()
    print("DATABASE REPAIR: 'products' table reset and seeded.")

if __name__ == "__main__":
    repair_database()