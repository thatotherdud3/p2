import sqlite3
import os

DB_PATH = "glh_coop.db"

def initialize_ledger():
    print("SYSTEM LOG: Commencing Database Initialization Protocol...")

    # Step 1: Purge existing ledger to ensure a clean slate
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print("SYSTEM LOG: Legacy database purged.")

    # Step 2: Establish connection and build schema
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            product_id INTEGER PRIMARY KEY AUTOINCREMENT,
            producer_id INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            price REAL NOT NULL,
            stock_level INTEGER NOT NULL,
            allergen_info TEXT NOT NULL,
            batch_number TEXT NOT NULL,
            product_image TEXT
        )
    ''')
    print("SYSTEM LOG: Schema established.")

    # Step 3: Define the Baseline Inventory Payload
    baseline_inventory = [
        (1, "Heirloom Carrots", 4.50, 450, "No Allergens Present", "BATCH-2026-A1", "placeholder.png"),
        (1, "Swiss Chard", 3.00, 120, "No Allergens Present", "BATCH-2026-A2", "placeholder.png"),
        (1, "Pasture Eggs", 7.50, 0, "Eggs", "BATCH-2026-B1", "placeholder.png"),
        (1, "Raw Honey", 18.00, 42, "No Allergens Present", "BATCH-2026-C1", "placeholder.png")
    ]

    # Step 4: Batch inject the payload into the ledger
    cursor.executemany('''
        INSERT INTO products (
            producer_id, 
            product_name, 
            price, 
            stock_level, 
            allergen_info, 
            batch_number, 
            product_image
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', baseline_inventory)

    conn.commit()
    conn.close()
    
    print(f"SYSTEM LOG: Initialization complete. {len(baseline_inventory)} assets injected into the ledger.")

if __name__ == "__main__":
    initialize_ledger()