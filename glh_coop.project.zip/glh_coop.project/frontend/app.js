/* ==========================================================================
   G L H // CO-OP - DATA INJECTION BRIDGE (app.js)
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const API_URL = "http://127.0.0.1:8000/products";
  fetchInventoryData(API_URL);
});

function fetchInventoryData(url) {
  const cacheBustUrl = `${url}?t=${new Date().getTime()}`;

  fetch(cacheBustUrl, { cache: "no-store" })
    .then((response) => {
      if (!response.ok)
        throw new Error("Network latency or server rejection detected.");
      return response.json();
    })
    .then((data) => {
      console.log("SYSTEM LOG: Data payload secured.", data);
      distributeData(data);
    })
    .catch((error) => console.error("SYSTEM ERROR:", error));
}

function distributeData(inventory) {
  const shopGrid = document.getElementById("shop-inventory-grid");
  const ledgerTable = document.getElementById("producer-ledger-body");

  if (shopGrid) populateShop(inventory, shopGrid);
  if (ledgerTable) populateLedger(inventory, ledgerTable);
}

/* --- CLIENT NODE: SHOP PRODUCE INJECTION --- */
function populateShop(inventory, container) {
  container.innerHTML = "";

  inventory.forEach((item) => {
    const card = document.createElement("div");
    card.className = "product-card";

    // Dynamic Asset Routing
    let imagePath = "placeholder.png";
    if (item.product_image && item.product_image !== "placeholder.png") {
      imagePath = `assets/${item.product_image}`;
    }

    // Dynamic Stock Status & Button Logic
    let status = "IN STOCK";
    let badgeClass = "active";
    let actionText = "ADD TO CART";
    let actionIcon = "+";

    if (item.stock_level === 0) {
      status = "OUT OF STOCK";
      badgeClass = "out-of-stock";
      actionText = "NOT AVAILABLE";
      actionIcon = "/";
    } else if (item.stock_level <= 20) {
      status = "LOW STOCK";
      badgeClass = "low-stock";
    }

    // Brutalist String Formatting
    let formattedAllergens = `[${item.allergen_info.toUpperCase()}]`;
    let formattedPrice = `£${parseFloat(item.price).toFixed(2)}`;

    card.innerHTML = `
        <div class="product-image-slot" style="width: 100%; aspect-ratio: 4 / 3; overflow: hidden; border-bottom: 1px solid #111111;">
          <img
            class="product-image"
            src="${imagePath}"
            alt="${item.product_name}"
            style="width: 100%; height: 100%; object-fit: cover; display: block; background-color: #e0e0e0;"
          />
        </div>
        <div class="product-details">
          <div class="product-header">
            <span class="product-vendor">PRODUCER ID: ${item.producer_id}</span>
            <div class="product-meta-right">
              <span class="box-index">${item.batch_number}</span>
              <span class="status-badge ${badgeClass}">${status}</span>
            </div>
          </div>
          <h2 class="box-title">${item.product_name}</h2>
          <span class="product-allergen">${formattedAllergens}</span>
          <span class="product-price">${formattedPrice}</span>
        </div>
        <a href="#" class="product-action">
          <span>${actionText}</span>
          <span class="action-icon">${actionIcon}</span>
        </a>
    `;

    container.appendChild(card);
  });
}

/* --- PRODUCER NODE: LEDGER INJECTION --- */
function populateLedger(inventory, container) {
  container.innerHTML = "";

  inventory.forEach((item) => {
    let status = "ACTIVE";
    let badgeClass = "active";

    if (item.stock_level === 0) {
      status = "OUT OF STOCK";
      badgeClass = "out-of-stock";
    } else if (item.stock_level <= 20) {
      status = "LOW STOCK";
      badgeClass = "low-stock";
    }

    const row = document.createElement("tr");
    row.innerHTML = `
            <td class="sku-cell">${item.batch_number}</td>
            <td class="name-cell">${item.product_name}</td>
            <td class="data-cell">${item.stock_level}</td>
            <td class="data-cell">£${parseFloat(item.price).toFixed(2)}</td>
            <td class="data-cell">
                <span class="status-badge ${badgeClass}">${status}</span>
            </td>
            <td class="action-cell">
                <button class="ledger-remove-btn" onclick="deleteProduct(${item.product_id})">[ REMOVE ]</button>
            </td>
        `;
    container.appendChild(row);
  });
}

/* ==========================================================================
   WRITE OPERATIONS: PRODUCER INTAKE MANIFEST
   ========================================================================== */

const ledgerForm = document.getElementById("ledger-form");

if (ledgerForm) {
  ledgerForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const allergenCheckboxes = document.querySelectorAll(
      ".allergen-check:checked",
    );
    if (allergenCheckboxes.length === 0) {
      alert(
        "SYSTEM HALT: Regulatory compliance failure. Select at least one allergen.",
      );
      return;
    }

    const formData = new FormData();
    const imageFile = document.getElementById("input-image").files[0];

    formData.append(
      "batch_number",
      ledgerForm.querySelector('input[placeholder="e.g. BATCH-2026-X1"]').value,
    );
    formData.append(
      "product_name",
      ledgerForm.querySelector('input[placeholder="Product Descriptor"]').value,
    );
    formData.append(
      "stock_level",
      document.getElementById("input-stock").value,
    );
    formData.append("price", document.getElementById("input-price").value);

    let allergens = Array.from(allergenCheckboxes)
      .map((cb) => cb.parentElement.textContent.trim())
      .join(", ");
    formData.append("allergen_info", allergens);

    if (imageFile) {
      formData.append("product_image", imageFile);
    }

    fetch("http://127.0.0.1:8000/products", {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (!response.ok) throw new Error("Server rejected the asset upload.");
        return response.json();
      })
      .then((data) => {
        alert("Stock and Visual Asset successfully committed.");
        ledgerForm.reset();
        fetchInventoryData("http://127.0.0.1:8000/products");
      })
      .catch((error) => {
        console.error("POST ERROR:", error);
        alert("SYSTEM HALT: Failed to commit stock. " + error.message);
      });
  });
}

/* --- DELETE OPERATION --- */
function deleteProduct(productId) {
  if (
    !confirm(
      `SYSTEM QUERY: Authorize permanent deletion of Product ID ${productId}?`,
    )
  )
    return;

  fetch(`http://127.0.0.1:8000/products/${productId}`, {
    method: "DELETE",
    mode: "cors",
    headers: { "Access-Control-Allow-Origin": "*" },
  })
    .then((response) => {
      if (response.ok) {
        console.log(`DELETION SUCCESS: ID ${productId} purged.`);
        fetchInventoryData("http://127.0.0.1:8000/products");
      } else {
        throw new Error("Server rejected the purge request.");
      }
    })
    .catch((error) => {
      console.error("DELETION ERROR:", error);
      alert("CRITICAL ERROR: Purge failed.");
    });
}
