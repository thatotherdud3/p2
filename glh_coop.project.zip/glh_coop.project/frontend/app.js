/* ==========================================================================
   G L H // CO-OP - DATA INJECTION BRIDGE (app.js)
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    const API_URL = "http://127.0.0.1:8000/products";
    fetchInventoryData(API_URL);
});

function fetchInventoryData(url) {
    const cacheBustUrl = `${url}?t=${new Date().getTime()}`;
    
    fetch(cacheBustUrl, { cache: "no-store" })
        .then(response => {
            if (!response.ok) throw new Error("Network latency or server rejection detected.");
            return response.json();
        })
        .then(data => {
            console.log("SYSTEM LOG: Data payload secured.", data);
            distributeData(data);
        })
        .catch(error => console.error("SYSTEM ERROR:", error));
}

function distributeData(inventory) {
    const shopGrid = document.getElementById("shop-inventory-grid");
    const ledgerTable = document.getElementById("producer-ledger-body");

    if (shopGrid) populateShop(inventory, shopGrid);
    if (ledgerTable) populateLedger(inventory, ledgerTable);
}

/* --- CLIENT NODE: SHOP PRODUCE INJECTION --- */
function populateShop(inventory, container) {
    container.innerHTML = ""; 
    
    inventory.forEach(item => {
        const card = document.createElement("a");
        card.href = "#";
        card.className = "product-card";
        
        card.innerHTML = `
            <div class="product-image-slot">
                <img src="placeholder.png" alt="${item.product_name}" class="product-image">
            </div>
            <div class="product-details">
                <div class="product-header">
                    <span class="product-vendor">PRODUCER ID: ${item.producer_id}</span>
                    <div class="product-meta-right">
                        <span class="product-price">£${item.price.toFixed(2)}</span>
                    </div>
                </div>
                <h3 class="box-title">${item.product_name}</h3>
                <span class="product-allergen">ALLERGENS: ${item.allergen_info}</span>
            </div>
            <button class="product-action">
                <span>ADD TO CART</span>
                <span>+</span>
            </button>
        `;
        container.appendChild(card);
    });
}

/* --- PRODUCER NODE: LEDGER INJECTION --- */
function populateLedger(inventory, container) {
    console.log("RECOGNIZED INVENTORY:", inventory); 
    container.innerHTML = ""; 
    
    inventory.forEach(item => {
        let status = "ACTIVE";
        let badgeClass = "active";
        
        if (item.stock_level === 0) {
            status = "OUT OF STOCK";
            badgeClass = "out-of-stock";
        } else if (item.stock_level <= 20) {
            status = "LOW STOCK";
            badgeClass = "low-stock";
        }

        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="sku-cell">${item.batch_number}</td>
            <td class="name-cell">${item.product_name}</td>
            <td class="data-cell">${item.stock_level}</td>
            <td class="data-cell">£${parseFloat(item.price).toFixed(2)}</td>
            <td class="data-cell">
                <span class="status-badge ${badgeClass}">${status}</span>
            </td>
            <td class="action-cell">
                <button class="ledger-remove-btn" onclick="deleteProduct(${item.product_id})">[ REMOVE ]</button>
            </td>
        `;
        container.appendChild(row);
    });
}

/* ==========================================================================
   WRITE OPERATIONS: PRODUCER INTAKE MANIFEST
   ========================================================================== */

const ledgerForm = document.getElementById("ledger-form");

if (ledgerForm) {
    ledgerForm.addEventListener("submit", function(event) {
        event.preventDefault(); 

        const allergenCheckboxes = document.querySelectorAll(".allergen-check:checked");
        if (allergenCheckboxes.length === 0) {
            alert("SYSTEM HALT: Regulatory compliance failure. Select at least one allergen.");
            return;
        }

        const batchNumber = ledgerForm.querySelector('input[placeholder="e.g. BATCH-2026-X1"]').value;
        const productName = ledgerForm.querySelector('input[placeholder="Product Descriptor"]').value;
        const stockLevel = parseInt(document.getElementById("input-stock").value, 10);
        const priceValue = parseFloat(document.getElementById("input-price").value);

        let allergens = Array.from(allergenCheckboxes)
            .map(cb => cb.parentElement.textContent.trim())
            .join(", ");

        const payload = {
            batch_number: batchNumber,
            product_name: productName,
            stock_level: stockLevel,
            price: priceValue,
            allergen_info: allergens
        };

        fetch("http://127.0.0.1:8000/products", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(err => { throw new Error(err.message || "Server error."); });
            }
            return response.json();
        })
        .then(data => {
            alert("Stock successfully committed to the ledger.");
            ledgerForm.reset(); 
            fetchInventoryData("http://127.0.0.1:8000/products"); 
        })
        .catch(error => {
            console.error("POST ERROR:", error);
            alert("SYSTEM HALT: Failed to commit stock. " + error.message);
        });
    });
}

/* --- DELETE OPERATION --- */

function deleteProduct(productId) {
    // Phase 1: Debugging Alert (Confirms the button is talking to the JS)
    alert("PURGE PROTOCOL TRIGGERED FOR ID: " + productId); 

    // Phase 2: User Authorization
    if (!confirm(`SYSTEM QUERY: Authorize permanent deletion of Product ID ${productId}?`)) return;

    // Phase 3: Transmission to API
    fetch(`http://127.0.0.1:8000/products/${productId}`, {
        method: "DELETE",
        mode: 'cors', 
        headers: { "Access-Control-Allow-Origin": "*" }
    })
    .then(response => {
        if (response.ok) {
            console.log(`DELETION SUCCESS: ID ${productId} purged.`);
            // Phase 4: State Refresh (Reloads the table automatically)
            fetchInventoryData("http://127.0.0.1:8000/products");
        } else {
            throw new Error("Server rejected the purge request.");
        }
    })
    .catch(error => {
        console.error("DELETION ERROR:", error);
        alert("CRITICAL ERROR: Purge failed. Check PowerShell terminal.");
    });
}